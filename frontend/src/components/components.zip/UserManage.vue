<template>
  <v-subheader class="subheader"
    >계정 설정
    <v-btn color="primary" @click="logOut">로그아웃</v-btn>
  </v-subheader>
  <v-divider></v-divider>
</template>

<script>
export default {
  data() {
    return {
      //필요한 데이터 넣을 예정
    };
  },
  methods: {
    logOut() {
      //로그아웃
    },
    //버튼 기능 추가 바람
  },
};
</script>

<style scoped></style>
